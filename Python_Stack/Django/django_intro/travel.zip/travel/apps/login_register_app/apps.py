from django.apps import AppConfig


class LoginRegisterAppConfig(AppConfig):
    name = 'login_register_app'
