using Microsoft.AspNetCore.Mvc;
namespace DojoSurvey
{
    public class MainController : Controller
    {
        [HttpGet("")]
        public IActionResult Main()
        {
            return View();
        }

        [HttpPost("form_submission")]
        public IActionResult FormSubmission(string NameField, string Location, string Language, string Comment)
        {
            ViewBag.name = NameField;
            ViewBag.location = Location;
            ViewBag.language = Language;
            ViewBag.comment = Comment;
            return View();
        }
    }
}