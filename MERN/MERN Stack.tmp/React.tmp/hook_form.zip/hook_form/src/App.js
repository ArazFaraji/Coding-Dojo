import React from 'react';
import RegisterForm from './Components/Form';


function App() {
  return (
    <div className="App">


    
      <RegisterForm />
      {/* <TableofForm submittedInfo={[]}/> */}
    </div>
  );
}

export default App;
